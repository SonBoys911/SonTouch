#!/system/bin/sh

sleep 2
  ui_print "××××××××××××××××××××"
  ui_print "  SonTouch🍄"
  ui_print "××××××××××××××××××××"
  ui_print "  Version : 1.0"
  ui_print "××××××××××××××××××××"
  ui_print "  Special For You"
  ui_print "××××××××××××××××××××"
sleep 2 

ui_print "Installing SonTouch"
sleep 5